# Mission: Master C# to Independently Design Features in BarnStormer3

## Why

Varun currently relies on AI to write code for the BarnStormer3 Unity game project. He wants to become self-sufficient — able to read, understand, write, and design C# features entirely on his own.

## Goal

Be able to design and implement a complete game feature (like MissionPursuit, StreakQuest, or ModularPack) from scratch, including:
- Manager classes with state machines
- Sub-managers for session, rewards, tasks
- ViewModels for UI
- State transitions and lifecycle management
- Data persistence (blob save/restore)
- Event-driven architecture

## Success Criteria

1. Can read any C# file in BarnStormer3 and understand what it does line-by-line
2. Can explain OOP concepts (inheritance, polymorphism, abstraction, encapsulation) with BarnStormer3 examples
3. Can identify and apply design patterns (Singleton, State Machine, Observer, etc.) used in the codebase
4. Can design a new feature's architecture from scratch: choose the right base classes, define states, create sub-managers
5. Can write a feature independently without AI assistance

## Learning Path

### Phase 1: C# Syntax Crash Course (Day 1-2)
- All fundamentals in C# spelling: types, control flow, methods, collections, properties
- Null safety operators, LINQ, lambdas, events preview
- Pattern matching, casting

### Phase 2: OOP Deep Dive (Day 3-5)
- Classes, inheritance, constructors
- Abstract classes vs interfaces vs virtual methods
- Generics (how `StateMachineV2State<ManagerType, TriggerType>` works)
- Delegates, Events, Action/Func in depth
- Partial classes

### Phase 3: Design Patterns (Day 6-8)
- Singleton (managers with `Instance`)
- State Machine pattern (SolidMachine, triggers, transitions)
- Observer pattern (events)
- Template Method (abstract base with virtual hooks)

### Phase 4: BarnStormer3 Architecture (Day 9-12)
- StateMachineV2Manager — the base class for all features
- StateMachineV2SubManager — session, reward, task managers
- State lifecycle (NotStarted → ActiveForAll → Bootstrap → Active → Expired)
- ViewModels and UI binding
- Blob save/restore for persistence
- Event subscription patterns

### Phase 5: Feature Dissection (Day 13-16)
- MissionPursuit end-to-end
- StreakQuest end-to-end
- ModularPack end-to-end

### Phase 6: Design Your Own Feature (Day 17-18)
- Given a spec, design the architecture
- Write production-quality code independently

## Context

- **Project**: BarnStormer3 (Unity mobile game, FarmVille-style)
- **Language**: C# with Unity
- **Codebase location**: `/Users/varun.hegde/Desktop/BarnStormer3`
- **Key directories**: `Assets/Scripts/Game/` contains feature code
- **Framework**: Uses SolidState library for state machines, custom StateMachineV2 base classes
