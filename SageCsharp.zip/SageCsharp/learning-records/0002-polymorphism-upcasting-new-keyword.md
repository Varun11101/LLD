# 0002: Polymorphism, Upcasting, and the `new` Keyword

## Date
2026-09-17

## Context
Varun asked about the pattern where a variable is typed as the parent class but holds a child object, and vice versa. Also confused about the `new` keyword on method/property declarations — thought it was related to hiding but wasn't sure why it existed or how it differed from `override`.

## Key Insights Covered

### Upcasting
- `Pokemon p = new Garchomp()` is valid because Garchomp IS-A Pokemon
- The variable type controls what you can *access*; the actual object type controls what *runs*
- Used for polymorphism: treat a list of mixed subtypes uniformly through a shared interface

### virtual + override = polymorphism
- `virtual` on the parent = "child may replace this"
- `override` on the child = "I am replacing this"
- When called through any typed variable, the most-derived override always wins
- This is **dynamic dispatch** — C# checks the actual object at runtime

### `new` on methods/properties (NOT `new ClassName()`)
- Used to **hide** a parent member with a new one of the same name
- Does NOT enable polymorphism — which version runs depends on the variable type, not the object type
- In BarnStormer3: `ModularPackManager` uses `public new ProtoModularPack protoData` and `public new SolidMachine<ModularFeatureTrigger> machine` because the base properties are not `virtual` — so `override` isn't allowed
- Purpose: convenience — get a properly-typed property without casting everywhere inside the child class

### Downcasting
- Going from parent variable → child variable
- `(Garchomp)p` — throws if wrong type
- `p as Garchomp` — returns null if wrong type
- `if (p is Garchomp g)` — safest, pattern matching, C# 7+

## BarnStormer3 Connections
- `StateMachineV2State<ManagerType, TriggerType>` — defines `virtual DoEntering()`, `abstract RegisterHandlers()`
- `ModularPackActiveState` — `override DoEntering()`, `override RegisterHandlers()`
- `StateMachineV2Manager` — holds `SolidMachineBase machine` (parent type)
- `ModularPackManager` — `public new SolidMachine<ModularFeatureTrigger> machine` (shadows with typed version)

## What's Next
- Interfaces vs Abstract Classes — when to use each
- The Template Method pattern (abstract base + virtual hooks) — this is exactly what StateMachineV2 uses
