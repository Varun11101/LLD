# Notes

## Learner Profile
- **Name**: Varun Hegde
- **Current level**: 2 YOE developer, 8 months on BarnStormer3. Can read and navigate code fluently. Gap is in writing/designing from scratch without AI.
- **Work context**: Works on BarnStormer3 daily, has been relying on AI to write code.
- **Learning style**: Wants concise explanations, not too much detail. Prefers real codebase examples over abstract theory.
- **Motivation**: Independence — wants to stop relying on AI and write features himself.
- **Key gap**: Not syntax/basics — it's understanding the *why* behind architectural choices, and having the confidence to make those choices independently.

## Preferences
- Keep lessons short and punchy. No walls of text.
- Always tie concepts back to BarnStormer3 code he actually works with.
- Focus on "what you need to know to write code" not academic completeness.
- Features to reference: MissionPursuit, StreakQuest, ModularPack (he says these are "really good" examples).
- Teach C# basics first, then OOP, then codebase-specific patterns.

## Key Codebase Patterns to Teach Later
- `StateMachineV2Manager` — abstract base class for all features
- `StateMachineV2SubManager` — sub-managers (session, rewards, tasks)
- `StateMachineV2State<ManagerType, TriggerType>` — generic state base
- `SolidMachine<TriggerType>` — state machine with trigger-based transitions
- `getSubManager<T>()` — accessing sub-managers
- Partial classes (`StreakQuestManager.cs`, `StreakQuestManager.SubManagers.cs`, etc.)
- Event pattern: `public static event Action OnSomething;` + `RaiseSomething()`
- ViewModelBase inheritance for UI
- Blob save/restore pattern for persistence
- `ProtoData` pattern for configuration
