# Resources

## Primary Resources

### Microsoft C# Documentation
- **URL**: https://learn.microsoft.com/en-us/dotnet/csharp/
- **Type**: Official documentation
- **Trust level**: Authoritative (official source)
- **Notes**: The definitive reference for C# language features. Use the "Tour of C#" and "Fundamentals" sections for learning, "Language Reference" for lookup.

### C# Programming Guide (Microsoft)
- **URL**: https://learn.microsoft.com/en-us/dotnet/csharp/programming-guide/
- **Type**: Tutorial/guide
- **Trust level**: Authoritative
- **Notes**: Excellent structured walkthrough of OOP concepts, generics, delegates, events.

### Unity Scripting Reference
- **URL**: https://docs.unity3d.com/ScriptReference/
- **Type**: API documentation
- **Trust level**: Authoritative
- **Notes**: For Unity-specific classes like MonoBehaviour, GameObject, etc.

## Secondary Resources

### C# in a Nutshell (Joseph Albahari)
- **URL**: https://www.oreilly.com/library/view/c-12-in/9781098147433/
- **Type**: Book
- **Trust level**: High (industry standard reference)
- **Notes**: Dense but comprehensive. Good for looking up specific language features.

### Refactoring Guru - Design Patterns
- **URL**: https://refactoring.guru/design-patterns
- **Type**: Tutorial site
- **Trust level**: High
- **Notes**: Excellent visual explanations of Singleton, State, Observer patterns with C# examples.

## Codebase Resources

### BarnStormer3 Key Files
- **StateMachineV2Manager**: `Assets/Scripts/Game/StateMachineV2/BaseModels/StateMachineV2Manager.cs`
- **StateMachineV2SubManager**: `Assets/Scripts/Game/StateMachineV2/BaseModels/StateMachineV2SubManager.cs`
- **StateMachineV2State**: `Assets/Scripts/Game/StateMachineV2/BaseStates/StateMachineV2State.cs`
- **StreakQuestManager**: `Assets/Scripts/Game/StreakQuest/Managers/StreakQuestManager.cs`
- **ModularPackManager**: `Assets/Scripts/Game/ModularPack/ModularPackManager.cs`
- **MissionPursuitManager**: `Assets/Scripts/Game/MissionPursuit/MissionPursuitManager.cs`
- **StateMachineV2Initializer**: `Assets/Scripts/Game/StateMachineV2/StateMachineV2Initializer.cs`
