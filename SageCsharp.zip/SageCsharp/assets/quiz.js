// Tracks whether a question has already been attempted (first try detection)
const _quizAttempted = {};

function checkAnswer(quizId, selectedBtn, isCorrect) {
    const quiz = document.getElementById(quizId);
    const options = quiz.querySelectorAll('.quiz-option');
    const feedback = quiz.querySelector('.quiz-feedback');

    const isFirstAttempt = !_quizAttempted[quizId];
    _quizAttempted[quizId] = true;

    // Disable all options
    options.forEach(opt => {
        opt.style.pointerEvents = 'none';
        if (opt.dataset.correct === 'true') {
            opt.classList.add('correct');
        }
    });

    if (!isCorrect) {
        selectedBtn.classList.add('incorrect');
    }

    // Show feedback
    feedback.style.display = 'block';
    if (isCorrect) {
        feedback.style.background = quiz.classList.contains('checkpoint') ? '#0f2a1a' : '#d5f5e3';
        feedback.style.color = quiz.classList.contains('checkpoint') ? '#3fb950' : '';
        feedback.textContent = feedback.dataset.correct;
    } else {
        feedback.style.background = quiz.classList.contains('checkpoint') ? '#2a0f0f' : '#fadbd8';
        feedback.style.color = quiz.classList.contains('checkpoint') ? '#f85149' : '';
        feedback.textContent = feedback.dataset.incorrect;
    }

    // Award XP via gamification system
    if (typeof window.onQuizAnswered === 'function') {
        window.onQuizAnswered(quizId, isCorrect, isFirstAttempt);
    }
}
