/* ═══════════════════════════════════════════════════════════════════
   SAGE C# COURSE — PROGRESS SYSTEM  v3
   Pokémon Platinum / Sinnoh theme

   XP     : quizzes + manual section claims
   P$     : manual section claims only → spend in Poké Mart
   Party  : buy Pokémon with P$, level them up with XP (10 XP / level)

   Rank thresholds are stretched across the full ~25-lesson course.
   Phase 2 ends around 2000 XP. Phase 3 around 3500. Phase 4 ~5800.
   Champion and beyond are true endgame.
═══════════════════════════════════════════════════════════════════ */

/* ── Trainer Ranks ───────────────────────────────────────────────── */
/* ── Trainer Ranks — stretched across the full course ─────────────
   Phase 2 (lessons 01–07 + labs) ≈ 0–2400 XP
   Phase 3 (design patterns) ≈ 2400–5100 XP
   Phase 4 (BarnStormer3 arch) ≈ 5100–9000 XP
   Elite Four + Champion = true endgame after ALL lessons
──────────────────────────────────────────────────────────────────── */
const RANKS = [
    { id: 'new_trainer', name: 'New Trainer',           emoji: '🎒', min: 0,    next: 250,   color: '#8b949e', location: 'Twinleaf Town — just starting out' },
    { id: 'route',       name: 'Route Traveller',        emoji: '🌿', min: 250,  next: 600,   color: '#3fb950', location: 'Route 201 → Sandgem Town' },
    { id: 'pc_regular',  name: 'Pokémon Center Regular', emoji: '💊', min: 600,  next: 1100,  color: '#e74c3c', location: 'Jubilife City' },
    { id: 'badge1',      name: 'Coal Badge',             emoji: '⛏️', min: 1100, next: 1700,  color: '#95a5a6', location: 'Oreburgh Gym — Roark defeated' },
    { id: 'badge2',      name: 'Forest Badge',           emoji: '🌲', min: 1700, next: 2400,  color: '#3fb950', location: 'Eterna Gym — Gardenia defeated' },
    { id: 'badge3',      name: 'Cobble Badge',           emoji: '🥊', min: 2400, next: 3200,  color: '#ffa657', location: 'Veilstone Gym — Maylene defeated' },
    { id: 'badge4',      name: 'Fen Badge',              emoji: '🌊', min: 3200, next: 4100,  color: '#58a6ff', location: 'Pastoria Gym — Crasher Wake defeated' },
    { id: 'badge5',      name: 'Relic Badge',            emoji: '🏛️', min: 4100, next: 5100,  color: '#d2a8ff', location: 'Hearthome Gym — Fantina defeated' },
    { id: 'badge6',      name: 'Mine Badge',             emoji: '⚙️', min: 5100, next: 6200,  color: '#ffa657', location: 'Canalave Gym — Byron defeated' },
    { id: 'badge7',      name: 'Icicle Badge',           emoji: '❄️', min: 6200, next: 7500,  color: '#a8d8ea', location: 'Snowpoint Gym — Candice defeated' },
    { id: 'badge8',      name: 'Beacon Badge',           emoji: '⚡', min: 7500, next: 9000,  color: '#f1c40f', location: 'Sunyshore Gym — Volkner defeated' },
    { id: 'elite4',      name: 'Elite Four',             emoji: '🔥', min: 9000, next: 11000, color: '#f78166', location: 'Pokémon League — Aaron, Bertha, Flint, Lucian' },
    { id: 'champion',    name: 'Sinnoh Champion',        emoji: '🏆', min: 11000,next: 14000, color: '#d2a8ff', location: 'Hall of Fame — Cynthia defeated' },
    { id: 'pokedex',     name: 'Pokédex Completed',      emoji: '✨', min: 14000,next: Infinity, color: '#f1c40f', location: '486 Pokémon — True Completion' },
];

/* ── Pokémon roster with full evolution lines ────────────────────────
   evolutionFrom : id of the pre-evolution (evolution-only forms have cost 0)
   evolvesAt     : level at which this Pokémon can evolve
   evolvesTo     : id of the next form
   Buying a base form adds it at Lv.1. Level it up with XP.
   When level >= evolvesAt, an Evolve button appears on the party card.
──────────────────────────────────────────────────────────────────── */
const POKEMON_ROSTER = [
    // ── Starters (always available) ──────────────────────────────────
    { id:'turtwig',   name:'Turtwig',   type:'Grass',          cost:50,  rankRequired:'new_trainer', emoji:'🌱', rarity:'Starter',   evolvesAt:18, evolvesTo:'grotle' },
    { id:'grotle',    name:'Grotle',    type:'Grass',          cost:0,   rankRequired:'new_trainer', emoji:'🐢', rarity:'Starter',   evolvesAt:32, evolvesTo:'torterra',  evolutionFrom:'turtwig' },
    { id:'torterra',  name:'Torterra',  type:'Grass/Ground',   cost:0,   rankRequired:'new_trainer', emoji:'🌍', rarity:'Starter',   evolutionFrom:'grotle' },
    { id:'chimchar',  name:'Chimchar',  type:'Fire',           cost:50,  rankRequired:'new_trainer', emoji:'🔥', rarity:'Starter',   evolvesAt:14, evolvesTo:'monferno' },
    { id:'monferno',  name:'Monferno',  type:'Fire/Fighting',  cost:0,   rankRequired:'new_trainer', emoji:'🦊', rarity:'Starter',   evolvesAt:36, evolvesTo:'infernape', evolutionFrom:'chimchar' },
    { id:'infernape', name:'Infernape', type:'Fire/Fighting',  cost:0,   rankRequired:'new_trainer', emoji:'🐒', rarity:'Starter',   evolutionFrom:'monferno' },
    { id:'piplup',    name:'Piplup',    type:'Water',          cost:50,  rankRequired:'new_trainer', emoji:'🐧', rarity:'Starter',   evolvesAt:16, evolvesTo:'prinplup' },
    { id:'prinplup',  name:'Prinplup',  type:'Water',          cost:0,   rankRequired:'new_trainer', emoji:'🐦', rarity:'Starter',   evolvesAt:36, evolvesTo:'empoleon',  evolutionFrom:'piplup' },
    { id:'empoleon',  name:'Empoleon',  type:'Water/Steel',    cost:0,   rankRequired:'new_trainer', emoji:'🐟', rarity:'Starter',   evolutionFrom:'prinplup' },
    // ── Gible line — available from start (Garchomp is your fav!) ────
    { id:'gible',     name:'Gible',     type:'Dragon/Ground',  cost:80,  rankRequired:'new_trainer', emoji:'🦈', rarity:'Rare',      evolvesAt:24, evolvesTo:'gabite',    desc:'Small but fierce. Has big dreams.' },
    { id:'gabite',    name:'Gabite',    type:'Dragon/Ground',  cost:0,   rankRequired:'new_trainer', emoji:'🐊', rarity:'Rare',      evolvesAt:48, evolvesTo:'garchomp',  evolutionFrom:'gible' },
    { id:'garchomp',  name:'Garchomp',  type:'Dragon/Ground',  cost:0,   rankRequired:'new_trainer', emoji:'🦷', rarity:'Very Rare', evolutionFrom:'gabite',   desc:'The land shark. Cynthia\'s ace.' },
    // ── Common (always available) ─────────────────────────────────────
    { id:'starly',    name:'Starly',    type:'Normal/Flying',  cost:20,  rankRequired:'new_trainer', emoji:'🐤', rarity:'Common',    evolvesAt:14, evolvesTo:'staravia' },
    { id:'staravia',  name:'Staravia',  type:'Normal/Flying',  cost:0,   rankRequired:'new_trainer', emoji:'🦅', rarity:'Common',    evolvesAt:34, evolvesTo:'staraptor', evolutionFrom:'starly' },
    { id:'staraptor', name:'Staraptor', type:'Normal/Flying',  cost:0,   rankRequired:'new_trainer', emoji:'🦁', rarity:'Uncommon',  evolutionFrom:'staravia' },
    { id:'shinx',     name:'Shinx',     type:'Electric',       cost:25,  rankRequired:'new_trainer', emoji:'⚡', rarity:'Common',    evolvesAt:15, evolvesTo:'luxio' },
    { id:'luxio',     name:'Luxio',     type:'Electric',       cost:0,   rankRequired:'new_trainer', emoji:'🔱', rarity:'Common',    evolvesAt:30, evolvesTo:'luxray',    evolutionFrom:'shinx' },
    { id:'luxray',    name:'Luxray',    type:'Electric',       cost:0,   rankRequired:'new_trainer', emoji:'🦁', rarity:'Uncommon',  evolutionFrom:'luxio' },
    { id:'bidoof',    name:'Bidoof',    type:'Normal',         cost:10,  rankRequired:'new_trainer', emoji:'🦫', rarity:'Common',    evolvesAt:15, evolvesTo:'bibarel' },
    { id:'bibarel',   name:'Bibarel',   type:'Normal/Water',   cost:0,   rankRequired:'new_trainer', emoji:'🦦', rarity:'Common',    evolutionFrom:'bidoof' },
    // ── Route Traveller unlocks ───────────────────────────────────────
    { id:'budew',     name:'Budew',     type:'Grass/Poison',   cost:40,  rankRequired:'route',       emoji:'🌹', rarity:'Uncommon',  evolvesAt:20, evolvesTo:'roselia' },
    { id:'roselia',   name:'Roselia',   type:'Grass/Poison',   cost:0,   rankRequired:'route',       emoji:'🌸', rarity:'Uncommon',  evolvesAt:40, evolvesTo:'roserade',  evolutionFrom:'budew' },
    { id:'roserade',  name:'Roserade',  type:'Grass/Poison',   cost:0,   rankRequired:'route',       emoji:'🌺', rarity:'Rare',      evolutionFrom:'roselia' },
    { id:'ponyta',    name:'Ponyta',    type:'Fire',           cost:50,  rankRequired:'route',       emoji:'🐴', rarity:'Uncommon',  evolvesAt:40, evolvesTo:'rapidash' },
    { id:'rapidash',  name:'Rapidash',  type:'Fire',           cost:0,   rankRequired:'route',       emoji:'🦄', rarity:'Uncommon',  evolutionFrom:'ponyta' },
    { id:'drifloon',  name:'Drifloon',  type:'Ghost/Flying',   cost:50,  rankRequired:'route',       emoji:'🎈', rarity:'Uncommon',  evolvesAt:28, evolvesTo:'drifblim' },
    { id:'drifblim',  name:'Drifblim',  type:'Ghost/Flying',   cost:0,   rankRequired:'route',       emoji:'🎪', rarity:'Uncommon',  evolutionFrom:'drifloon' },
    // ── Coal Badge unlocks ────────────────────────────────────────────
    { id:'riolu',     name:'Riolu',     type:'Fighting',       cost:100, rankRequired:'badge1',      emoji:'🥊', rarity:'Rare',      evolvesAt:25, evolvesTo:'lucario' },
    { id:'lucario',   name:'Lucario',   type:'Fighting/Steel', cost:0,   rankRequired:'badge1',      emoji:'🐺', rarity:'Rare',      evolutionFrom:'riolu' },
    { id:'spiritomb', name:'Spiritomb', type:'Ghost/Dark',     cost:120, rankRequired:'badge1',      emoji:'👻', rarity:'Rare' },
    { id:'cranidos',  name:'Cranidos',  type:'Rock',           cost:80,  rankRequired:'badge1',      emoji:'🦕', rarity:'Rare',      evolvesAt:30, evolvesTo:'rampardos' },
    { id:'rampardos', name:'Rampardos', type:'Rock',           cost:0,   rankRequired:'badge1',      emoji:'🦖', rarity:'Rare',      evolutionFrom:'cranidos' },
    // ── Forest Badge unlocks ──────────────────────────────────────────
    { id:'togepi',    name:'Togepi',    type:'Normal',         cost:80,  rankRequired:'badge2',      emoji:'🥚', rarity:'Rare',      evolvesAt:20, evolvesTo:'togetic' },
    { id:'togetic',   name:'Togetic',   type:'Normal/Flying',  cost:0,   rankRequired:'badge2',      emoji:'🕊️', rarity:'Rare',      evolvesAt:50, evolvesTo:'togekiss',  evolutionFrom:'togepi' },
    { id:'togekiss',  name:'Togekiss',  type:'Normal/Flying',  cost:0,   rankRequired:'badge2',      emoji:'🌟', rarity:'Very Rare', evolutionFrom:'togetic' },
    // ── Fen Badge unlocks ─────────────────────────────────────────────
    { id:'magikarp',  name:'Magikarp',  type:'Water',          cost:5,   rankRequired:'badge4',      emoji:'🐠', rarity:'Common',    evolvesAt:20, evolvesTo:'gyarados',  desc:'Useless now. Unstoppable later.' },
    { id:'gyarados',  name:'Gyarados',  type:'Water/Flying',   cost:0,   rankRequired:'badge4',      emoji:'🐉', rarity:'Very Rare', evolutionFrom:'magikarp' },
    // ── Icicle Badge unlocks ──────────────────────────────────────────
    { id:'sneasel',   name:'Sneasel',   type:'Dark/Ice',       cost:150, rankRequired:'badge7',      emoji:'🌙', rarity:'Rare',      evolvesAt:40, evolvesTo:'weavile' },
    { id:'weavile',   name:'Weavile',   type:'Dark/Ice',       cost:0,   rankRequired:'badge7',      emoji:'🌑', rarity:'Very Rare', evolutionFrom:'sneasel' },
    // ── All 8 Badges unlocks ──────────────────────────────────────────
    { id:'dialga',    name:'Dialga',    type:'Steel/Dragon',   cost:500, rankRequired:'badge8',      emoji:'💎', rarity:'Legendary' },
    { id:'palkia',    name:'Palkia',    type:'Water/Dragon',   cost:500, rankRequired:'badge8',      emoji:'💠', rarity:'Legendary' },
    { id:'giratina',  name:'Giratina',  type:'Ghost/Dragon',   cost:600, rankRequired:'elite4',      emoji:'👁️', rarity:'Legendary' },
];

/* ── Poké Mart items ────────────────────────────────────────────── */
const SHOP_ITEMS = [
    { id: 'theme_pokeball', name: 'Poké Ball Theme',    emoji: '🔴', cost: 100, type: 'theme',   desc: 'HUD turns classic red. Gotta catch \'em all.' },
    { id: 'theme_dialga',   name: 'Dialga Theme',       emoji: '💎', cost: 100, type: 'theme',   desc: 'HUD turns steel blue. Master of time.' },
    { id: 'theme_palkia',   name: 'Palkia Theme',       emoji: '🌸', cost: 150, type: 'theme',   desc: 'HUD turns pearl purple. Master of space.' },
    { id: 'shield',         name: 'Full Restore',       emoji: '💊', cost: 75,  type: 'powerup', desc: 'One wrong answer won\'t break your streak. Single use.' },
    { id: 'double_xp',      name: 'Rare Candy ×5',      emoji: '🍬', cost: 150, type: 'powerup', desc: 'Next 5 correct quiz answers worth 2× XP. Single use.' },
    { id: 'title_rival',    name: 'Title: Rival',       emoji: '😤', cost: 200, type: 'title',   desc: 'Barry energy. Always in a hurry to be better.' },
    { id: 'title_ace',      name: 'Title: Ace Trainer', emoji: '🌸', cost: 200, type: 'title',   desc: 'Recognised as an elite trainer across Sinnoh.' },
    { id: 'title_champ',    name: 'Title: Sinnoh Champ',emoji: '👑', cost: 250, type: 'title',   desc: 'You stood where Cynthia stood. Enough said.' },
];

const PARTY_MAX = 6;
const XP_PER_LEVEL = 10;

/* ── Rank order map (for unlock checks) ─────────────────────────── */
const RANK_ORDER = RANKS.map(r => r.id);
function rankIndex(id) { return RANK_ORDER.indexOf(id); }
function rankUnlocked(currentRankId, requiredRankId) {
    return rankIndex(currentRankId) >= rankIndex(requiredRankId);
}

/* ── Default state ──────────────────────────────────────────────── */
function defaultState() {
    return {
        xp: 0,
        pokedollars: 0,
        streak: 0,
        answeredQuestions: {},
        claimedRewards: {},
        ownedItems: [],
        activeTheme: null,
        activeTitle: null,
        shieldActive: false,
        doubleXPRemaining: 0,
        party: [],       // [{ id, name, level, xpInvested }]
        ownedPokemon: [] // ids of purchased pokemon
    };
}

/* ── Storage ────────────────────────────────────────────────────── */
function getState() {
    try {
        const raw = localStorage.getItem('sage_cs_v2');
        if (!raw) return defaultState();
        return Object.assign(defaultState(), JSON.parse(raw));
    } catch { return defaultState(); }
}
function saveState(s) { localStorage.setItem('sage_cs_v2', JSON.stringify(s)); }

/* ── Rank helpers ───────────────────────────────────────────────── */
function getRank(xp) {
    for (let i = RANKS.length - 1; i >= 0; i--) {
        if (xp >= RANKS[i].min) return RANKS[i];
    }
    return RANKS[0];
}

/* ── HUD ────────────────────────────────────────────────────────── */
function buildHUD() {
    if (document.getElementById('xp-hud')) return;
    const path = window.location.pathname;
    const isIndex = path.endsWith('index.html') || path.endsWith('/');
    const isRoot = !path.includes('/lessons/') && !path.includes('/reference/');
    const homeHref = isIndex ? '#' : isRoot ? 'index.html' : '../index.html';

    const hud = document.createElement('div');
    hud.id = 'xp-hud';
    hud.innerHTML = `
        <a class="hud-home" href="${homeHref}">🗺️ Sinnoh</a>
        <span class="hud-rank" id="hud-rank-label">New Trainer</span>
        <div class="hud-bar-wrap"><div class="hud-bar-fill" id="hud-bar" style="width:0%"></div></div>
        <span class="hud-xp" id="hud-xp-label">0 / 200 XP</span>
        <span class="hud-streak" id="hud-streak">🔥 <span id="hud-streak-count">0</span></span>
        <span class="hud-pokédollars" id="hud-pokédollars">P$ <span id="hud-pd-count">0</span></span>
        <button class="hud-avatar" id="hud-avatar" onclick="toggleProfile()" title="Trainer Card">🎮</button>
    `;
    document.body.prepend(hud);

    const panel = document.createElement('div');
    panel.id = 'profile-panel';
    panel.innerHTML = `<div class="profile-panel-inner"><button class="profile-close" onclick="toggleProfile()">✕</button><div id="profile-content"></div></div>`;
    document.body.appendChild(panel);
    panel.addEventListener('click', e => { if (e.target === panel) toggleProfile(); });

    const banner = document.createElement('div');
    banner.id = 'rank-up-banner';
    document.body.appendChild(banner);

    applyTheme(getState().activeTheme);
    refreshHUD();
}

function refreshHUD() {
    const s = getState();
    const rank = getRank(s.xp);
    const pct = rank.next === Infinity ? 100
        : Math.min(100, ((s.xp - rank.min) / (rank.next - rank.min)) * 100);

    const title = s.activeTitle ? ` · ${s.activeTitle}` : '';
    const shield = s.shieldActive ? ' 💊' : '';
    const dxp = s.doubleXPRemaining > 0 ? ` 🍬×${s.doubleXPRemaining}` : '';

    document.getElementById('hud-rank-label').textContent = `${rank.emoji} ${rank.name}${title}${shield}${dxp}`;
    document.getElementById('hud-bar').style.width = pct + '%';
    document.getElementById('hud-xp-label').textContent = rank.next === Infinity
        ? `${s.xp} XP — COMPLETE`
        : `${s.xp - rank.min} / ${rank.next - rank.min} XP`;
    document.getElementById('hud-pd-count').textContent = s.pokedollars;

    const streakEl = document.getElementById('hud-streak');
    document.getElementById('hud-streak-count').textContent = s.streak;
    streakEl.style.opacity = s.streak >= 2 ? '1' : '0';
}

/* ── Award XP ───────────────────────────────────────────────────── */
function awardXP(amount) {
    const s = getState();
    const oldRank = getRank(s.xp);
    s.xp += amount;
    const newRank = getRank(s.xp);
    saveState(s);
    refreshHUD();
    showPop(`+${amount} XP`, '#ffa657');
    if (newRank.id !== oldRank.id) showRankUp(newRank);
}

/* ── Award PokéDollars ──────────────────────────────────────────── */
function awardPokedollars(amount) {
    const s = getState();
    s.pokedollars += amount;
    saveState(s);
    refreshHUD();
    showPop(`+P$${amount}`, '#f1c40f');
}

/* ── Claim / unclaim ─────────────────────────────────────────────── */
window.claimReward = function(btn, rewardId, xp, pd) {
    const s = getState();
    if (s.claimedRewards[rewardId]) {
        delete s.claimedRewards[rewardId];
        if (xp > 0) s.xp = Math.max(0, s.xp - xp);
        if (pd > 0) s.pokedollars = Math.max(0, s.pokedollars - pd);
        saveState(s);
        refreshHUD();
        btn.classList.remove('claimed');
        btn.innerHTML = btn.dataset.originalLabel;
        showPop('↩ Unclaimed', '#8b949e');
    } else {
        if (!btn.dataset.originalLabel) btn.dataset.originalLabel = btn.innerHTML;
        s.claimedRewards[rewardId] = true;
        saveState(s);
        btn.classList.add('claimed');
        btn.innerHTML = '✓ Undo?';
        if (xp > 0) awardXP(xp);
        if (pd > 0) setTimeout(() => awardPokedollars(pd), 300);
    }
};

function restoreClaimButtons() {
    const s = getState();
    document.querySelectorAll('[data-reward-id]').forEach(btn => {
        const id = btn.dataset.rewardId;
        if (!btn.dataset.originalLabel) btn.dataset.originalLabel = btn.innerHTML;
        if (s.claimedRewards[id]) { btn.classList.add('claimed'); btn.innerHTML = '✓ Undo?'; }
    });
}

/* ── Quiz XP ─────────────────────────────────────────────────────── */
window.onQuizAnswered = function(questionId, isCorrect, isFirstAttempt) {
    const s = getState();
    if (s.answeredQuestions[questionId]) return;
    if (isCorrect) {
        s.answeredQuestions[questionId] = true;
        s.streak = (s.streak || 0) + 1;
        let xp = isFirstAttempt ? 15 : 5;
        if (s.doubleXPRemaining > 0) { xp *= 2; s.doubleXPRemaining--; }
        if (s.streak % 3 === 0) { xp += 10; setTimeout(() => showPop('🔥 Streak! +10', '#ffa657'), 500); }
        saveState(s);
        awardXP(xp);
    } else {
        if (s.shieldActive) {
            s.shieldActive = false; saveState(s); refreshHUD();
            showPop('💊 Full Restore used!', '#58a6ff');
        } else {
            s.streak = 0; saveState(s); refreshHUD();
        }
    }
};

/* ── Pokémon: buy ────────────────────────────────────────────────── */
window.buyPokemon = function(pokemonId) {
    const poke = POKEMON_ROSTER.find(p => p.id === pokemonId);
    if (!poke) return;
    const s = getState();
    const rank = getRank(s.xp);

    if (!rankUnlocked(rank.id, poke.rankRequired)) {
        const req = RANKS.find(r => r.id === poke.rankRequired);
        showPop(`Locked until ${req ? req.name : poke.rankRequired}!`, '#f85149');
        return;
    }
    if (s.ownedPokemon.includes(pokemonId)) {
        // Already owned — add to party if space
        if (s.party.length >= PARTY_MAX) { showPop('Party is full! (6 max)', '#f85149'); return; }
        if (s.party.find(p => p.id === pokemonId)) { showPop('Already in party!', '#8b949e'); return; }
        s.party.push({ id: pokemonId, name: poke.name, level: 1, xpInvested: 0 });
        saveState(s);
        showPop(`${poke.emoji} ${poke.name} added to party!`, '#3fb950');
        renderProfile();
        renderShop();
        return;
    }
    if (s.pokedollars < poke.cost) { showPop('Not enough P$!', '#f85149'); return; }

    s.pokedollars -= poke.cost;
    s.ownedPokemon.push(pokemonId);
    if (s.party.length < PARTY_MAX) {
        s.party.push({ id: pokemonId, name: poke.name, level: 1, xpInvested: 0 });
    }
    saveState(s);
    refreshHUD();
    showPop(`${poke.emoji} ${poke.name} caught!`, '#3fb950');
    renderProfile();
    renderShop();
};

/* ── Pokémon: level up ───────────────────────────────────────────── */
window.levelUpPokemon = function(pokemonId) {
    const s = getState();
    const member = s.party.find(p => p.id === pokemonId);
    if (!member) return;
    if (member.level >= 100) { showPop('Already at Lv.100!', '#8b949e'); return; }
    if (s.xp < XP_PER_LEVEL) { showPop(`Need ${XP_PER_LEVEL} XP to level up!`, '#f85149'); return; }

    s.xp -= XP_PER_LEVEL;
    member.level++;
    member.xpInvested = (member.xpInvested || 0) + XP_PER_LEVEL;
    saveState(s);
    refreshHUD();
    const poke = POKEMON_ROSTER.find(p => p.id === pokemonId);
    showPop(`${poke ? poke.emoji : '⭐'} Lv.${member.level}!`, '#f1c40f');
    if (poke && poke.evolvesAt && member.level >= poke.evolvesAt) {
        setTimeout(() => showPop(`✨ ${poke.name} can evolve!`, '#f1c40f'), 700);
    }
    renderProfile();
};

/* ── Pokémon: evolve ────────────────────────────────────────────── */
window.evolvePokemon = function(pokemonId) {
    const s = getState();
    const member = s.party.find(p => p.id === pokemonId);
    if (!member) return;
    const poke = POKEMON_ROSTER.find(p => p.id === pokemonId);
    if (!poke || !poke.evolvesTo) { showPop('Cannot evolve!', '#8b949e'); return; }
    if (member.level < poke.evolvesAt) {
        showPop(`Need Lv.${poke.evolvesAt} to evolve!`, '#f85149');
        return;
    }
    const nextForm = POKEMON_ROSTER.find(p => p.id === poke.evolvesTo);
    if (!nextForm) { showPop('Evolution data missing!', '#f85149'); return; }
    const oldName = member.name;
    member.id = nextForm.id;
    member.name = nextForm.name;
    if (!s.ownedPokemon.includes(nextForm.id)) s.ownedPokemon.push(nextForm.id);
    saveState(s);
    renderProfile();
    if (typeof renderShop === 'function') renderShop();
    showPop(`✨ ${oldName} → ${nextForm.name}!`, '#f1c40f');
};

/* ── Pokémon: remove from party ─────────────────────────────────── */
window.removeFromParty = function(pokemonId) {
    const s = getState();
    s.party = s.party.filter(p => p.id !== pokemonId);
    saveState(s);
    renderProfile();
    renderShop();
    showPop('Sent to PC Box', '#8b949e');
};

/* ── Pokémon: get level descriptor ──────────────────────────────── */
function getLevelDesc(level) {
    if (level < 10)  return 'Just hatched';
    if (level < 20)  return 'Getting stronger';
    if (level < 35)  return 'Solid training';
    if (level < 50)  return 'Well trained';
    if (level < 65)  return 'Powerful';
    if (level < 80)  return 'Elite level';
    if (level < 100) return 'Near max power';
    return '✨ MAX POWER';
}

/* ── Poké Mart: buy item ─────────────────────────────────────────── */
window.buyItem = function(itemId) {
    const item = SHOP_ITEMS.find(i => i.id === itemId);
    if (!item) return;
    const s = getState();
    if (s.pokedollars < item.cost) { showPop('Not enough P$!', '#f85149'); return; }
    if (item.type !== 'powerup' && s.ownedItems.includes(itemId)) { showPop('Already owned!', '#8b949e'); return; }

    s.pokedollars -= item.cost;
    if (item.type === 'theme') {
        s.activeTheme = itemId;
        s.ownedItems = s.ownedItems.filter(i => !i.startsWith('theme_'));
        s.ownedItems.push(itemId);
        applyTheme(itemId);
    } else if (item.type === 'title') {
        s.activeTitle = item.name.replace('Title: ', '');
        s.ownedItems = s.ownedItems.filter(i => !i.startsWith('title_'));
        s.ownedItems.push(itemId);
    } else if (item.type === 'powerup') {
        if (itemId === 'shield') s.shieldActive = true;
        if (itemId === 'double_xp') s.doubleXPRemaining = (s.doubleXPRemaining || 0) + 5;
    }
    saveState(s);
    refreshHUD();
    showPop(`${item.emoji} Purchased!`, '#3fb950');
    renderShop();
    renderProfile();
};

/* ── Trainer Card (profile panel) ───────────────────────────────── */
function toggleProfile() {
    const panel = document.getElementById('profile-panel');
    if (!panel.classList.contains('open')) renderProfile();
    panel.classList.toggle('open');
}

function renderProfile() {
    const s = getState();
    const rank = getRank(s.xp);
    const content = document.getElementById('profile-content');
    if (!content) return;

    // Party section
    const partyHTML = s.party.length === 0
        ? '<p class="party-empty">No Pokémon in party. Buy one from the Poké Mart!</p>'
        : s.party.map(member => {
            const poke = POKEMON_ROSTER.find(p => p.id === member.id);
            const emoji = poke ? poke.emoji : '❓';
            const type = poke ? poke.type : '?';
            const lvlPct = Math.min(100, (member.level / 100) * 100);
            const canLevelUp = s.xp >= XP_PER_LEVEL && member.level < 100;
            const canEvolve = poke && poke.evolvesAt && member.level >= poke.evolvesAt;
            const evolveTarget = canEvolve ? POKEMON_ROSTER.find(p => p.id === poke.evolvesTo) : null;
            // Level bar fills to next evolution threshold if one exists, otherwise to 100
            const barTarget = poke && poke.evolvesAt ? poke.evolvesAt : 100;
            const barPct = Math.min(100, (member.level / barTarget) * 100);
            const nextEvolveName = evolveTarget ? evolveTarget.name : null;
            return `
                <div class="party-card ${canEvolve ? 'can-evolve' : ''}">
                    <div class="party-card-emoji">${emoji}${canEvolve ? '<span class="evolve-ready">✨</span>' : ''}</div>
                    <div class="party-card-info">
                        <div class="party-card-name">${member.name} <span class="party-card-level">Lv.${member.level}</span></div>
                        <div class="party-card-type">${type}</div>
                        <div class="party-card-desc">${getLevelDesc(member.level)}${poke && poke.evolvesAt && !canEvolve ? ` · evolves at Lv.${poke.evolvesAt}` : ''}</div>
                        <div class="party-lvl-bar-wrap"><div class="party-lvl-bar-fill" style="width:${barPct}%"></div></div>
                    </div>
                    <div class="party-card-actions">
                        ${canEvolve ? `<button class="party-btn evolve-btn" onclick="evolvePokemon('${member.id}')" title="Evolve into ${nextEvolveName}">✨ Evolve!</button>` : ''}
                        <button class="party-btn levelup-btn ${canLevelUp ? '' : 'disabled'}"
                            onclick="levelUpPokemon('${member.id}')"
                            title="${canLevelUp ? `Spend ${XP_PER_LEVEL} XP to level up` : `Need ${XP_PER_LEVEL} XP`}">
                            ${canLevelUp ? `+Lv (${XP_PER_LEVEL}XP)` : `Need ${XP_PER_LEVEL}XP`}
                        </button>
                        <button class="party-btn remove-btn" onclick="removeFromParty('${member.id}')" title="Send to PC Box">📦</button>
                    </div>
                </div>
            `;
        }).join('');

    // Rank rows
    const rankRows = RANKS.map(r => {
        const unlocked = s.xp >= r.min;
        const isCurrent = r.id === rank.id;
        const pct = r.next === Infinity ? 100
            : Math.min(100, Math.max(0, ((s.xp - r.min) / (r.next - r.min)) * 100));
        return `
            <div class="rank-row ${unlocked ? 'unlocked' : 'locked'} ${isCurrent ? 'current' : ''}">
                <span class="rank-row-emoji">${r.emoji}</span>
                <div class="rank-row-info">
                    <div class="rank-row-name">${r.name}${isCurrent ? ' ← you are here' : ''}</div>
                    <div class="rank-row-sublabel">${r.location}</div>
                    <div class="rank-row-bar-wrap"><div class="rank-row-bar-fill" style="width:${pct}%;background:${r.color}"></div></div>
                    <div class="rank-row-xp">${unlocked ? (r.next === Infinity ? `${s.xp} XP — Complete!` : `${r.min}–${r.next} XP`) : `Unlocks at ${r.min} XP`}</div>
                </div>
            </div>`;
    }).join('');

    const powerups = [];
    if (s.shieldActive) powerups.push('💊 Full Restore active');
    if (s.doubleXPRemaining > 0) powerups.push(`🍬 Rare Candy: ${s.doubleXPRemaining} uses left`);

    content.innerHTML = `
        <div class="profile-header">
            <div class="profile-avatar-big">${rank.emoji}</div>
            <div>
                <div class="profile-rank-name">${rank.name}${s.activeTitle ? ` · ${s.activeTitle}` : ''}</div>
                <div class="profile-sublabel">${rank.location}</div>
                <div class="profile-stats">${s.xp} XP &nbsp;·&nbsp; P$${s.pokedollars} &nbsp;·&nbsp; ${s.party.length}/${PARTY_MAX} Pokémon</div>
            </div>
        </div>
        ${powerups.length ? `<div class="profile-powerups">${powerups.join(' &nbsp; ')}</div>` : ''}
        <h4 class="profile-section-title">Your Party</h4>
        <div class="party-list">${partyHTML}</div>
        <h4 class="profile-section-title">Sinnoh Journey — Rank Progress</h4>
        <div class="rank-list">${rankRows}</div>
    `;
}

/* ── Render Poké Mart ────────────────────────────────────────────── */
window.renderShop = function() {
    const s = getState();
    const rank = getRank(s.xp);

    // Items tab
    const itemsContainer = document.getElementById('shop-items-grid');
    if (itemsContainer) {
        itemsContainer.innerHTML = SHOP_ITEMS.map(item => {
            const owned = s.ownedItems.includes(item.id);
            const canAfford = s.pokedollars >= item.cost;
            const isActive = (item.type === 'theme' && s.activeTheme === item.id)
                || (item.type === 'title' && s.activeTitle === item.name.replace('Title: ', ''));
            let btnLabel = `Buy — P$${item.cost}`;
            let btnClass = 'shop-buy-btn';
            let disabled = '';
            if (item.type === 'powerup') {
                if (!canAfford) { btnClass += ' cant-afford'; disabled = 'disabled'; }
            } else {
                if (owned && isActive) { btnLabel = '✓ Active'; btnClass += ' owned-active'; disabled = 'disabled'; }
                else if (owned) btnLabel = 'Activate';
                else if (!canAfford) { btnClass += ' cant-afford'; disabled = 'disabled'; }
            }
            return `<div class="shop-card"><div class="shop-card-emoji">${item.emoji}</div><div class="shop-card-name">${item.name}</div><div class="shop-card-desc">${item.desc}</div><button class="${btnClass}" onclick="buyItem('${item.id}')" ${disabled}>${btnLabel}</button></div>`;
        }).join('');
    }

    // Pokémon tab
    const pokeContainer = document.getElementById('shop-pokemon-grid');
    if (pokeContainer) {
        pokeContainer.innerHTML = POKEMON_ROSTER.map(poke => {
            const owned = s.ownedPokemon.includes(poke.id);
            const inParty = s.party.find(p => p.id === poke.id);
            const unlocked = rankUnlocked(rank.id, poke.rankRequired);
            const canAfford = s.pokedollars >= poke.cost;
            const reqRank = RANKS.find(r => r.id === poke.rankRequired);

            let btnLabel, btnClass = 'shop-buy-btn', disabled = '';
            if (!unlocked) {
                btnLabel = `🔒 ${reqRank ? reqRank.name : poke.rankRequired}`;
                btnClass += ' cant-afford'; disabled = 'disabled';
            } else if (owned && inParty) {
                btnLabel = '✓ In Party'; btnClass += ' owned-active'; disabled = 'disabled';
            } else if (owned) {
                btnLabel = 'Add to Party';
            } else if (!canAfford) {
                btnLabel = `P$${poke.cost} (need more)`; btnClass += ' cant-afford'; disabled = 'disabled';
            } else {
                btnLabel = `Catch — P$${poke.cost}`;
            }

            const rarityColor = { 'Common':'#8b949e','Uncommon':'#3fb950','Starter':'#58a6ff','Rare':'#ffa657','Very Rare':'#f78166','Legendary':'#f1c40f' }[poke.rarity] || '#8b949e';

            return `
                <div class="shop-card pokemon-card ${!unlocked ? 'locked-card' : ''}">
                    <div class="shop-card-emoji">${poke.emoji}</div>
                    <div class="shop-card-name">${poke.name}</div>
                    <div class="pokemon-card-type">${poke.type}</div>
                    <div class="pokemon-card-rarity" style="color:${rarityColor}">${poke.rarity}</div>
                    <button class="${btnClass}" onclick="buyPokemon('${poke.id}')" ${disabled}>${btnLabel}</button>
                </div>`;
        }).join('');
    }

    const balanceEl = document.getElementById('shop-ryo-balance');
    if (balanceEl) balanceEl.textContent = `Your balance: P$${s.pokedollars}`;
};

/* ── Apply HUD theme ────────────────────────────────────────────── */
function applyTheme(themeId) {
    document.body.classList.remove('theme-pokeball', 'theme-dialga', 'theme-palkia');
    if (themeId === 'theme_pokeball') document.body.classList.add('theme-pokeball');
    if (themeId === 'theme_dialga')   document.body.classList.add('theme-dialga');
    if (themeId === 'theme_palkia')   document.body.classList.add('theme-palkia');
}

/* ── Animations ─────────────────────────────────────────────────── */
function showPop(text, color) {
    const pop = document.createElement('div');
    pop.className = 'xp-pop';
    pop.style.background = color || '#ffa657';
    pop.textContent = text;
    document.body.appendChild(pop);
    setTimeout(() => pop.remove(), 1700);
}

function showRankUp(rank) {
    const banner = document.getElementById('rank-up-banner');
    if (!banner) return;
    banner.innerHTML = `🎉 ${rank.emoji} ${rank.name}!<br><small style="font-size:0.72rem;font-weight:400;opacity:0.85">${rank.location}</small>`;
    banner.classList.add('show');
    setTimeout(() => banner.classList.remove('show'), 4500);
}

/* ── Init ───────────────────────────────────────────────────────── */
function init() { buildHUD(); restoreClaimButtons(); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();
